export { default } from './Stake'
